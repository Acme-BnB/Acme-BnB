
package services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CommentService {

	// Managed repository -----------------------------------------------------

	/*
	 * @Autowired
	 * private CommentRepository commentRepository;
	 */

	// Supporting services ----------------------------------------------------

	// Constructors -----------------------------------------------------------

	// Simple CRUD methods ----------------------------------------------------

}
