package repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import domain.Vat;

public interface VatRepository extends JpaRepository<Vat, Integer>{

}
